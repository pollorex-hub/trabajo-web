<script setup lang="ts">
import { ref } from 'vue'
import { z } from 'zod'
import type { Evento } from '~/types/evento';


const props = defineProps<{
    evento: Evento
}>()

const emit = defineEmits<{
    (e: 'inscrito'): void
}>()

const fechaFormateada = computed(() => formatFechaCorta(props.evento.fecha))
const horaFormateada = computed(() => formatHora(props.evento.fecha))


const eventoAbiertoId = ref<string | number | null>(null)
const enviando = ref(false)
const mensajeError = ref('')

const datosFormulario = ref({
    nombre: '',
    apellido: '',
    email: ''
})
const errores = ref({
    nombre: '',
    apellido: '',
    email: ''
})

const esquemaFormulario = z.object({
    nombre: z.string().trim().min(2, { message: 'El nombre debe tener al menos 2 caracteres' }),
    apellido: z.string().trim().min(2, { message: 'El apellido debe tener al menos 2 caracteres' }),
    email: z.string().trim().email({ message: 'El email no es válido' })
})

type DatosFormulario = z.infer<typeof esquemaFormulario>

const limpiarErrores = () => {
    errores.value = { nombre: '', apellido: '', email: '' }
}

const correoNormalizado = () => datosFormulario.value.email.trim().toLowerCase()

const validarCorreoEnEvento = async () => {
    limpiarErrores()
    mensajeError.value = ''

    const resultado = esquemaFormulario.safeParse(datosFormulario.value as DatosFormulario)

    if (!resultado.success) {
        const erroresCampo = resultado.error.flatten().fieldErrors
        errores.value.nombre = erroresCampo.nombre?.[0] ?? ''
        errores.value.apellido = erroresCampo.apellido?.[0] ?? ''
        errores.value.email = erroresCampo.email?.[0] ?? ''
        return false
    }

    if (eventoAbiertoId.value === null) {
        mensajeError.value = 'No se pudo identificar el evento.'
        return false
    }

    try {
        const inscripciones = await $fetch<Array<{ eventId: number }>>(
            `/api/Inscrito/byEmail/${encodeURIComponent(correoNormalizado())}`
        )

        const yaInscritoEnEsteEvento = inscripciones.some(
            (inscripcion) => Number(inscripcion.eventId) === Number(eventoAbiertoId.value)
        )

        if (yaInscritoEnEsteEvento) {
            errores.value.email = 'Este correo ya está inscrito en este evento.'
            return false
        }

        return true
    } catch {
        return true
    }
}

const abrirFormulario = (id: string | number) => {
    eventoAbiertoId.value = id
    mensajeError.value = ''
}

const cerrarFormulario = () => {
    eventoAbiertoId.value = null
    limpiarErrores()
    mensajeError.value = ''
}

const enviarInscripcion = async () => {
    const correoValido = await validarCorreoEnEvento()

    if (!correoValido) {
        return
    }

    enviando.value = true

    try {
        await $fetch('/api/Inscrito', {
            method: 'POST',
            body: {
                nombre: datosFormulario.value.nombre,
                apellido: datosFormulario.value.apellido,
                email: correoNormalizado(),
                eventoId: eventoAbiertoId.value
            }
        })

        datosFormulario.value = { nombre: '', apellido: '', email: '' }
        eventoAbiertoId.value = null
        alert('Inscripción enviada correctamente.')
        emit('inscrito')
    } catch (error: any) {
        mensajeError.value = getApiErrorMessage(error, 'No se pudo registrar la inscripción')
    } finally {
        enviando.value = false
    }
}
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>


<template>
    <div
        class="overflow-hidden rounded-3xl border border-white/20 bg-white/10 backdrop-blur-xl shadow-2xl shadow-slate-950/30">
        <img class="h-56 w-full object-cover" alt="mi foto" :src="evento.imagen" />
        <div class="p-6">
            <p class="text-sm uppercase tracking-[0.25em] text-black">{{ evento.titulo }}</p>
            <div class="mt-4 space-y-3 text-black">
                <p><span class="font-semibold text-black">Lugar:</span> {{ evento.lugar }}</p>
                <p><span class="font-semibold text-black">fecha:</span> {{ fechaFormateada }}</p>
                <p><span class="font-semibold text-black">Hora:</span> {{ horaFormateada }}</p>
                <p><span class="font-semibold text-black">Valor:</span> ${{ evento.valor }}</p>
                <p class="m-0 text-slate-700">
                    <span class="font-semibold text-black">Inscritos:</span>
                    {{ evento._count?.inscrito ?? 0 }}
                </p>
            </div>
            <div class="mt-6 flex justify-end">
                <UButton label="Inscribir" class="bg-linear-to-r from-blue-600 to-purple-600 text-white border-0"
                    @click="abrirFormulario(evento.id)" />
            </div>
        </div>
    </div>


    <!-- Modal -->
    <Teleport to="body">
        <Transition name="fade">
            <div v-if="eventoAbiertoId !== null"
                class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4"
                @click.self="cerrarFormulario">
                <div class="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-slate-900">Inscribirse al evento</h3>
                        <button type="button" class="rounded-full p-1 text-slate-500 hover:bg-slate-100"
                            @click="cerrarFormulario">
                            ✕
                        </button>
                    </div>
                    <p class="mt-2 text-sm text-slate-600">Evento: {{ evento.titulo }}</p>

                    <UAlert
                        v-if="mensajeError"
                        class="mt-4"
                        color="error"
                        variant="soft"
                        :title="mensajeError"
                    />

                    <form @submit.prevent="enviarInscripcion" class="mt-4 space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700">Nombre</label>
                            <input v-model="datosFormulario.nombre" type="text" placeholder="Tu nombre"
                                class="mt-1 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" />
                            <p v-if="errores.nombre" class="mt-1 text-sm text-red-600">{{ errores.nombre }}</p>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700">Apellido</label>
                            <input v-model="datosFormulario.apellido" type="text" placeholder="Tu apellido"
                                class="mt-1 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" />
                            <p v-if="errores.apellido" class="mt-1 text-sm text-red-600">{{ errores.apellido }}</p>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700">Correo electrónico</label>
                            <input v-model="datosFormulario.email" type="email" placeholder="tu@email.com"
                                @blur="validarCorreoEnEvento"
                                class="mt-1 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" />
                            <p v-if="errores.email" class="mt-1 text-sm text-red-600">{{ errores.email }}</p>
                        </div>
                        <div class="flex items-center justify-end gap-3">
                            <button type="button"
                                class="rounded-2xl border border-slate-300 bg-white px-4 py-2 text-sm text-slate-700 hover:bg-slate-100"
                                @click="cerrarFormulario">
                                Cancelar
                            </button>
                            <button type="submit"
                                class="rounded-2xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
                                :disabled="enviando">
                                {{ enviando ? 'Enviando...' : 'Enviar inscripción' }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </Transition>
    </Teleport>

</template>
