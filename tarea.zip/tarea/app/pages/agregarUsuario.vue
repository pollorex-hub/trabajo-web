<script setup lang="ts">
import { ref, reactive } from 'vue'

const guardando = ref(false)
const errorFormulario = ref('')

const FormUsuario = reactive({
  nombre: '',
  apellido: '',
  email: '',
  password: '',
  rol: 'staff'
})

function limpiarFormulario() {
  FormUsuario.nombre = ''
  FormUsuario.apellido = ''
  FormUsuario.email = ''
  FormUsuario.password = ''
  FormUsuario.rol = 'staff'
}

async function guardarUsuario() {
  errorFormulario.value = ''
  guardando.value = true

  try {
    await $fetch('/api/Usuario', {
      method: 'POST',
      body: {
        nombre: FormUsuario.nombre,
        apellido: FormUsuario.apellido,
        email: FormUsuario.email,
        password: FormUsuario.password,
        rol: FormUsuario.rol
      }
    })

    limpiarFormulario()
    await navigateTo('/administracion')
  } catch (err: any) {
    errorFormulario.value = err?.data?.statusMessage || 'Error al guardar el usuario'
  } finally {
    guardando.value = false
  }
}
</script>

<template>
  <div class="min-h-screen flex items-center justify-center bg-black p-4">
    <form
      @submit.prevent="guardarUsuario"
      class="w-full max-w-lg bg-zinc-900 border border-zinc-800 shadow-xl shadow-black/50 rounded-2xl p-8"
    >
      <NuxtLink
        to="/administracion"
        class="inline-flex items-center gap-1 text-sm text-zinc-400 hover:text-white transition-colors mb-6"
      >
        <UIcon name="i-heroicons-arrow-left" class="w-4 h-4" />
        Volver a administración
      </NuxtLink>

      <div class="mb-6 text-center">
        <h2 class="text-2xl font-bold text-white">
          Nuevo Usuario
        </h2>
        <p class="text-sm text-zinc-400 mt-1">Completá los datos para crear una cuenta</p>
      </div>

      <div class="space-y-4">
        <UFormField label="Nombre" name="nombre">
          <UInput
            v-model="FormUsuario.nombre"
            color="neutral"
            variant="outline"
            placeholder="Ej: Juan"
            class="w-full"
          />
        </UFormField>

        <UFormField label="Apellido" name="apellido">
          <UInput
            v-model="FormUsuario.apellido"
            color="neutral"
            variant="outline"
            placeholder="Ej: Pérez"
            class="w-full"
          />
        </UFormField>

        <UFormField label="Email" name="email">
          <UInput
            v-model="FormUsuario.email"
            color="neutral"
            variant="outline"
            placeholder="tu@email.com"
            class="w-full"
          />
        </UFormField>

        <UFormField label="Password" name="password">
          <UInput
            type="password"
            v-model="FormUsuario.password"
            color="neutral"
            variant="outline"
            placeholder="Contraseña"
            class="w-full"
          />
        </UFormField>

        <UFormField label="Rol" name="rol">
          <USelect
            v-model="FormUsuario.rol"
            :items="['normal', 'staff']"
            color="neutral"
            variant="outline"
            class="w-full"
          />
        </UFormField>
      </div>

      <UAlert
        v-if="errorFormulario"
        color="error"
        variant="soft"
        class="mt-5"
        :title="errorFormulario"
      />

      <div class="flex justify-end mt-6">
        <UButton
          type="submit"
          label="Guardar usuario"
          :loading="guardando"
          size="lg"
          class="bg-white hover:bg-zinc-200 text-black shadow-md shadow-black/30 px-6"
        />
      </div>
    </form>
  </div>
</template>