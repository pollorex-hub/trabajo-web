<script setup lang="ts">
import type { Evento } from '~/types/evento';

const { data: eventos, pending, error, refresh } = await useFetch<Evento[]>('/api/Evento')

async function recargarEventos() {
    await refresh()
}
</script>

<template>
    <section class="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div class="mx-auto max-w-7xl">
            <div class="mb-8 flex items-center justify-center sm:flex-row">
                <div class="text-center sm:text-left">
                    <p class="text-sm uppercase tracking-[0.3em] text-black">Eventos públicos</p>
                    <h1 class="mt-4 text-4xl font-semibold text-black">Descubre los próximos eventos</h1>
                    <p class="mt-3 max-w-2xl text-black">
                        Consulta el título, fecha y hora, lugar, imagen, valor y cupo registrado. No necesitas iniciar
                        sesión para verlos.
                    </p>
                </div>
            </div>
        </div>

        <p v-if="pending" class="text-center text-black/60">Cargando eventos...</p>

        <p v-else-if="error" class="text-center text-red-500">
            No se pudieron cargar los eventos. Intenta recargar la página.
        </p>

        <div v-else class="grid gap-8 md:grid-cols-2 xl:grid-cols-3">
            <EventoCard
                v-for="evento in eventos"
                :key="evento.id"
                :evento="evento"
                @inscrito="recargarEventos"
            />
        </div>
    </section>

</template>