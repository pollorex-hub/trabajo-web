<script setup lang="ts">
import type { Evento } from '~/types/evento'

const { data: eventos, pending, error, refresh } = await useFetch<Evento[]>('/api/Evento')
const { data: usuarios, pending: usuariosPending, refresh: refreshUsuarios } = await useFetch('/api/Usuario')

async function eliminarUsuario(email: string) {
  const confirmar = confirm(`¿Eliminar usuario ${email}?`)
  if (!confirmar) return

  try {
    await $fetch(`/api/Usuario/${encodeURIComponent(email)}`, { method: 'DELETE' })
    await refreshUsuarios()
    useToast().add({ title: 'Usuario eliminado', duration: 2000, color: 'success' })
  } catch (err: any) {
    console.error('Error al eliminar usuario', err)
    useToast().add({ title: 'Error al eliminar usuario', description: err?.data?.statusMessage || '', color: 'error' })
  }
}
</script>

<template>
  <div class="min-h-screen flex items-center justify-center bg-black p-4">
    <div class="w-full max-w-5xl bg-zinc-900 border border-zinc-800 shadow-xl shadow-black/50 rounded-2xl p-8">
      <!-- Encabezado -->
      <div class="mb-10 text-center">
        <h1 class="text-3xl font-bold text-white">
          Administración
        </h1>
        <p class="text-sm text-zinc-400 mt-1">
          Gestiona los eventos y usuarios del sistema
        </p>
      </div>

      <!-- Sección Eventos -->
      <section class="mb-12">
        <div class="flex items-center justify-between mb-6">
          <h2 class="text-lg font-semibold text-white flex items-center gap-2">
            <span class="w-1.5 h-5 rounded-full bg-blue-500"></span>
            Eventos
          </h2>
          <NuxtLink
            to="/agregarEvento"
            class="font-medium text-sm text-white bg-blue-600 px-4 py-2 rounded-full hover:bg-blue-500 shadow-lg shadow-blue-900/30 transition-all duration-200"
          >
            + Agregar evento
          </NuxtLink>
        </div>

        <p v-if="pending" class="text-zinc-400 text-sm">
          Cargando eventos...
        </p>

        <p
          v-else-if="error"
          class="text-red-400 text-sm bg-white/5 border border-red-500/20 rounded-xl p-6 text-center"
        >
          No se pudieron cargar los eventos.
        </p>

        <div
          v-else-if="!eventos || eventos.length === 0"
          class="text-zinc-400 text-sm bg-white/5 border border-zinc-800 rounded-xl p-6 text-center"
        >
          No hay eventos registrados.
        </div>

        <div v-else class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
          <AdminCard v-for="evento in eventos" :key="evento.id" :evento="evento" @eliminado="refresh" />
        </div>
      </section>

      <!-- Sección Usuarios -->
      <section>
        <div class="flex items-center justify-between mb-6">
          <h2 class="text-lg font-semibold text-white flex items-center gap-2">
            <span class="w-1.5 h-5 rounded-full bg-blue-500"></span>
            Usuarios
          </h2>
          <NuxtLink
            to="/agregarUsuario"
            class="font-medium text-sm text-white bg-blue-600 px-4 py-2 rounded-full hover:bg-blue-500 shadow-lg shadow-blue-900/30 transition-all duration-200"
          >
            + Agregar usuario
          </NuxtLink>
        </div>

        <p v-if="usuariosPending" class="text-zinc-400 text-sm">
          Cargando usuarios...
        </p>

        <p
          v-else-if="usuarios?.length === 0"
          class="text-zinc-400 text-sm bg-white/5 border border-zinc-800 rounded-xl p-6 text-center"
        >
          No hay usuarios registrados.
        </p>

        <div v-else class="flex flex-col gap-3">
          <div
            v-for="usuario in usuarios"
            :key="usuario.email"
            class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 rounded-xl border border-zinc-800 bg-white/5 p-4 hover:border-zinc-700 hover:bg-white/[0.07] transition-colors duration-200"
          >
            <div class="w-full sm:w-auto flex items-center gap-3">
              <div class="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white text-sm font-medium shrink-0 shadow-md shadow-blue-900/40">
                {{ usuario.nombre?.[0] }}{{ usuario.apellido?.[0] }}
              </div>
              <div>
                <p class="font-semibold text-white">
                  {{ usuario.nombre }} {{ usuario.apellido }}
                </p>
                <p class="text-sm text-zinc-400">
                  {{ usuario.email }}
                </p>
                <p class="text-xs text-blue-300 uppercase tracking-wide mt-0.5">
                  {{ usuario.rol }}
                </p>
              </div>
            </div>

            <div class="w-full sm:w-auto flex justify-end">
              <UButton
                label="Eliminar"
                color="error"
                variant="soft"
                icon="i-heroicons-trash"
                @click="eliminarUsuario(usuario.email)"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>