<script setup lang="ts">
const guardando = ref(false)
const errorFormulario = ref('')

const FormEvento = reactive({
  titulo: '',
  fecha: '',
  hora: '',
  lugar: '',
  valor: undefined as number | undefined,
  archivo: null as File | null
})

function limpiarFormulario() {
  FormEvento.titulo = ''
  FormEvento.fecha = ''
  FormEvento.hora = ''
  FormEvento.lugar = ''
  FormEvento.valor = undefined
  FormEvento.archivo = null
}

const preview = ref('/uploads/default.jpg')

watch(() => FormEvento.archivo, (nuevo) => {
  preview.value = nuevo ? URL.createObjectURL(nuevo) : '/uploads/default.jpg'
})

async function guardarEvento() {
  errorFormulario.value = ''
  guardando.value = true

  try {
    const formData = new FormData()

    formData.append('titulo', FormEvento.titulo)
    formData.append('fecha', FormEvento.fecha)
    formData.append('hora', FormEvento.hora)
    formData.append('lugar', FormEvento.lugar)
    formData.append('valor', String(FormEvento.valor))

    if (FormEvento.archivo) {
      formData.append('imagen', FormEvento.archivo)
    }

    await $fetch('/api/Evento', {
      method: 'POST',
      body: formData
    })

    limpiarFormulario()
    await navigateTo('/administracion')
  } catch (err: any) {
    errorFormulario.value = err?.data?.statusMessage || 'Error al guardar el evento'
  } finally {
    guardando.value = false
  }
}
</script>

<template>
  <div class="min-h-screen flex items-center justify-center bg-black p-4">
    <div class="w-full max-w-2xl bg-zinc-900 border border-zinc-800 shadow-xl shadow-black/50 rounded-2xl p-8">

      <!-- Volver a administración -->
      <div class="mb-4">
        <NuxtLink
          to="/administracion"
          class="inline-flex items-center gap-1 text-sm text-zinc-400 hover:text-white transition-colors"
        >
          <UIcon name="i-heroicons-arrow-left" class="w-4 h-4" />
          Volver a administración
        </NuxtLink>
      </div>

      <div class="mb-6 text-center">
        <h2 class="text-2xl font-bold text-white">
          Nuevo evento
        </h2>
        <p class="text-sm text-zinc-400 mt-1">
          Completa los datos para publicar un nuevo evento
        </p>
      </div>

      <form class="space-y-6" @submit.prevent="guardarEvento">
        <!-- Datos principales -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <UFormField label="Título" name="titulo" class="sm:col-span-2">
            <UInput
              v-model="FormEvento.titulo"
              color="neutral"
              variant="outline"
              placeholder="Ej: Festival de algo"
              class="w-full"
            />
          </UFormField>

          <UFormField label="Lugar" name="lugar">
            <UInput
              v-model="FormEvento.lugar"
              color="neutral"
              variant="outline"
              placeholder="Ej: Villa Alemana"
              icon="i-heroicons-map-pin"
              class="w-full"
            />
          </UFormField>

          <UFormField label="Valor" name="valor">
            <UInput
              v-model="FormEvento.valor"
              color="neutral"
              variant="outline"
              placeholder="Ej: 10000"
              icon="i-heroicons-currency-dollar"
              class="w-full"
            />
          </UFormField>

          <UFormField label="Fecha" name="fecha">
            <UInput
              v-model="FormEvento.fecha"
              type="date"
              color="neutral"
              variant="outline"
              class="w-full"
            />
          </UFormField>

          <UFormField label="Hora" name="hora">
            <UInput
              v-model="FormEvento.hora"
              type="time"
              color="neutral"
              variant="outline"
              class="w-full"
            />
          </UFormField>
        </div>

        <!-- Imagen -->
        <UFormField label="Imagen">
          <UFileUpload
            v-model="FormEvento.archivo"
            accept="image/*"
            label="Arrastra tu imagen aquí"
            description="JPG, PNG o WebP"
            class="w-full min-h-32"
          />
        </UFormField>

        <!-- Error -->
        <UAlert
          v-if="errorFormulario"
          color="error"
          variant="soft"
          icon="i-heroicons-exclamation-triangle"
          :title="errorFormulario"
        />

        <!-- Acciones -->
        <div class="flex justify-end">
          <UButton
            type="submit"
            label="Guardar evento"
            :loading="guardando"
            size="lg"
            class="bg-white hover:bg-zinc-200 text-black shadow-md shadow-black/30 px-6"
          />
        </div>
      </form>
    </div>
  </div>
</template>