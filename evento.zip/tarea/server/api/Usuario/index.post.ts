import bcrypt from "bcryptjs";

export default defineEventHandler(async (event) => {
  // extraer los datos que se ingresaron en el formulario
  const { email, password, nombre, apellido, rol } = await readBody(event);

  const rolNormalizado = String(rol ?? '').trim().toLowerCase();
  const rolesPermitidos = ['normal', 'staff'];

  if (!rolesPermitidos.includes(rolNormalizado)) {
    throw createError({
      statusCode: 400,
      statusMessage: 'El rol debe ser normal o staff.',
    });
  }

  //crear el hash del password
  const hash = await bcrypt.hash(password, 12);

  // insertar el usuario en la BD
  try {
    const usuario = await prisma.usuario.create({
      data: {
        email,
        password: hash,
        nombre,
        apellido,
        rol: rolNormalizado,
      },
    });

    return {
      ok: true,
      usuario,
    };
  } catch (err: any) {
    // Manejar unique constraint violation (email duplicado)
    if (err?.code === 'P2002') {
      throw createError({ statusCode: 409, statusMessage: 'El email ya está registrado.' });
    }
    // Re-throw error genérico
    throw createError({ statusCode: 500, statusMessage: 'Error al crear usuario' });
  }
});
