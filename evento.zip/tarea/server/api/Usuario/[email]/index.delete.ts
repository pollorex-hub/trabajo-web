export default defineEventHandler(async (event) => {
    const { email } = event.context.params as { email?: string }

    if (!email) {
        throw createError({ statusCode: 400, statusMessage: 'Email requerido' })
    }

    try {
        const usuario = await prisma.usuario.delete({ where: { email } })
        return { ok: true, usuario }
    } catch (err: any) {
        if (err?.code === 'P2025') {
            throw createError({ statusCode: 404, statusMessage: 'Usuario no encontrado' })
        }
        throw createError({ statusCode: 500, statusMessage: 'Error al eliminar usuario' })
    }
})