import bcrypt from "bcryptjs"

export default defineEventHandler(async (event) => {
  const { email, password } = await readBody(event)

  if (!email || !password) {
    throw createError({ statusCode: 401, message: "Acceso Denegado, Intente nuevamente" })
  }

  const emailNormalizado = String(email).trim().toLowerCase()
  const passwordNormalizado = String(password).trim()

  const usuario = await prisma.usuario.findFirst({
    where: {
      email: emailNormalizado
    }
  })

  if (!usuario) {
    throw createError({ statusCode: 401, message: "Acceso Denegado, Intente nuevamente" })
  }

  const rolNormalizado = String(usuario.rol ?? '').trim().toLowerCase()
  const rolesPermitidos = ['normal', 'staff']

  if (!rolesPermitidos.includes(rolNormalizado)) {
    throw createError({ statusCode: 401, message: "Acceso Denegado, Intente nuevamente" })
  }

  const passwordValido = await bcrypt.compare(passwordNormalizado, usuario.password)

  if (!passwordValido) {
    throw createError({ statusCode: 401, message: "Acceso Denegado, Intente nuevamente" })
  }

  await setUserSession(event, {
    user: {
      email: usuario.email,
      nombre: usuario.nombre,
      apellido: usuario.apellido,
      rol: usuario.rol,
    }
  })

  return { ok: true }
})