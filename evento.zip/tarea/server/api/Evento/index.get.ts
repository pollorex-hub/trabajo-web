import { prisma } from '../../utils/prisma'

export default defineEventHandler(async () => {
  const eventos = await prisma.evento.findMany({
    include: {
      _count: {
        select: { inscrito: true }
      }
    }
  })

  return eventos
})