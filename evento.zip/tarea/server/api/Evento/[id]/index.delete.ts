export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))

  // Borra primero los inscritos asociados a este evento
  await prisma.inscritos.deleteMany({
    where: { eventId: id }
  })

  // Luego borra el evento
  await prisma.evento.delete({
    where: { id }
  })

  return { ok: true }
})