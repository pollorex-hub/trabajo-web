import { writeFile } from 'fs/promises'
import { join } from 'path'

export default defineEventHandler(async (event) => {
  const formData = await readFormData(event)

  // Datos del formulario
  const titulo = formData.get('titulo') as string
  const fecha  = formData.get('fecha') as string
  const hora   = formData.get('hora') as string
  const lugar  = formData.get('lugar') as string
  const valor  = formData.get('valor') as string
  const file   = formData.get('imagen') as File

  const fechaNormalizada = typeof fecha === 'string' ? fecha.trim() : ''
  const horaNormalizada = typeof hora === 'string' ? hora.trim() : ''


  const fechaHora = new Date(`${fechaNormalizada}T${horaNormalizada}:00`)

  // Manejo de imagen
  let rutaImagen = '/uploads/default.jpg'

  if (file && file.size > 0) {
    const nombre_archivo = `${Date.now()}-${file.name}`
    const buffer = Buffer.from(await file.arrayBuffer())
    await writeFile(join(process.cwd(), 'public', 'uploads', nombre_archivo), buffer)
    rutaImagen = `/uploads/${nombre_archivo}`
  }

  const valorNumerico = parseInt(valor)

  if (isNaN(valorNumerico)) {
    throw createError({ statusCode: 400, message: 'Valor inválido' })
  }

  // Guardar en BD
  const evento = await prisma.evento.create({
    data: {
      titulo,
      fecha:  fechaHora,
      lugar,
      valor:  valorNumerico,
      imagen: rutaImagen
    }
  })

  return{
    ok: true,
    evento
  } 
})