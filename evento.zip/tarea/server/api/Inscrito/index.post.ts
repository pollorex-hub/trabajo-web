export default defineEventHandler(async (event) => {
  const { email, nombre, apellido, eventoId } = await readBody(event)

  const emailNormalizado = String(email ?? '').trim().toLowerCase()
  const nombreNormalizado = String(nombre ?? '').trim()
  const apellidoNormalizado = String(apellido ?? '').trim()

  // Validar campos
  if (!emailNormalizado || !nombreNormalizado || !apellidoNormalizado || !eventoId) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Todos los campos son obligatorios.'
    })
  }

  // Verificar que no esté inscrito ya en este evento
  const yaInscrito = await prisma.inscritos.findFirst({
    where: {
      email: emailNormalizado,
      eventId: Number(eventoId)
    }
  })

  if (yaInscrito) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Ya estás inscrito en este evento.'
    })
  }

  const inscrito = await prisma.inscritos.create({
    data: {
      email: emailNormalizado,
      nombre: nombreNormalizado,
      apellido: apellidoNormalizado,
      eventId: Number(eventoId)
    }
  })

  return { ok: true, inscrito }
})