export default defineEventHandler(async (event) => {
    const email = getRouterParam(event, 'email')

    const inscripciones = await prisma.inscritos.findMany({
        where: { email },
        include: { eventos: true }
    })

    return inscripciones
})