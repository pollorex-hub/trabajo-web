export default defineEventHandler(async (event) => {
    const params = event.context.params
    console.log('Params:', params)
    const idParam = params?.id
    const id = Number(idParam)
    console.log('ID:', id)

    if (!idParam || isNaN(id)) {
        throw createError({ statusCode: 400, message: `ID inválido: ${idParam}` })
    }

    await prisma.inscritos.delete({
        where: { id }
    })

    return { ok: true }
})