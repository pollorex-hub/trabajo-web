export default defineEventHandler(async() =>{
    return await prisma.inscritos.findMany({
        orderBy:{email:'asc'},
    })
})
