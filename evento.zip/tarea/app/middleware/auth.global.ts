export default defineNuxtRouteMiddleware((to: any) => {
  const { loggedIn, user } = useUserSession();

  // Rutas que son públicas
  const rutasPublicas = ["/", "/login", "/inscritos"];
  const rutasSoloStaff = ["/administracion"];

  if (!loggedIn.value && !rutasPublicas.includes(to.path)) {
    return navigateTo("/login");
  }

  if (rutasSoloStaff.includes(to.path)) {
    const rol = String(user.value?.rol ?? '').trim().toLowerCase();

    if (rol !== 'staff') {
      return navigateTo('/');
    }
  }
});
