<script setup>
const menuAbierto = ref(false)

const { user, loggedIn, clear } = useUserSession()

const links = computed(() => {
  const rol = String(user.value?.rol ?? '').trim().toLowerCase()

  const enlaces = [
    { label: 'Inicio', to: '/' },
    { label: 'Inscritos', to: '/inscritos' }
  ]

  if (rol === 'staff') {
    enlaces.push({ label: 'Administración', to: '/administracion' })
  }

  return enlaces
})

async function cerrarSesion() {
  await clear()
  await navigateTo('/login')
}
</script>

<template>
  <div class="min-h-screen flex flex-col bg-slate-50">
    <header class="fixed top-0 left-0 right-0 z-50 shadow-lg bg-linear-to-r from-indigo-600 via-purple-700 to-sky-500">
      <nav class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between text-white">
        <!-- Logo / título -->
        <NuxtLink to="/" class="flex items-center gap-3">
          <div class="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center font-bold text-xl shadow-md">
            E
          </div>
          <span class="text-2xl font-bold tracking-wide">Events</span>
        </NuxtLink>

        <!-- Links escritorio -->
        <div class="hidden md:flex items-center gap-4">
          <NuxtLink v-for="link in links" :key="link.to" :to="link.to"
            class="font-medium px-4 py-2 rounded-full bg-white/10 border border-white/20 shadow hover:shadow-lg hover:bg-white hover:text-purple-700 transition-all duration-200">
            {{ link.label }}
          </NuxtLink>
        </div>

        <!-- Sesión escritorio -->
        <div class="hidden md:flex items-center gap-3">
          <template v-if="loggedIn && user">
            <div class="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20">
              <div class="h-7 w-7 rounded-full bg-white/30 flex items-center justify-center font-bold text-sm">
                {{ user.nombre?.charAt(0).toUpperCase() }}
              </div>
              <div class="flex flex-col leading-tight">
                <span class="text-sm font-semibold">{{ user.nombre }}</span>
                <span class="text-xs text-white/70 capitalize">{{ user.rol }}</span>
              </div>
            </div>

            <button type="button"
              class="font-medium px-4 py-2 rounded-full bg-white/10 border border-white/20 shadow hover:shadow-lg hover:bg-red-500 hover:border-red-500 transition-all duration-200"
              @click="cerrarSesion">
              Cerrar sesión
            </button>
          </template>

          <template v-else>
            <NuxtLink to="/login"
              class="font-medium px-4 py-2 rounded-full bg-white/10 border border-white/20 shadow hover:shadow-lg hover:bg-white hover:text-purple-700 transition-all duration-200">
              Iniciar sesión
            </NuxtLink>
          </template>
        </div>

        <!-- Botón móvil -->
        <button type="button" class="md:hidden p-2 rounded-lg bg-white/10 hover:bg-white/20 transition"
          @click="menuAbierto = !menuAbierto">
          <span class="sr-only">Abrir menú</span>

          <svg v-if="!menuAbierto" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
          </svg>

          <svg v-else class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </nav>

      <!-- Menú móvil -->
      <div v-if="menuAbierto" class="md:hidden px-4 pb-4 flex flex-col gap-3 text-white">
        <NuxtLink v-for="link in links" :key="link.to" :to="link.to"
          class="font-medium px-4 py-2 rounded-full bg-white/10 border border-white/20 shadow hover:bg-white hover:text-purple-700 transition text-center"
          @click="menuAbierto = false">
          {{ link.label }}
        </NuxtLink>

        <!-- Sesión móvil: usuario logueado -->
        <template v-if="loggedIn && user">
          <div class="flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20">
            <div class="h-7 w-7 rounded-full bg-white/30 flex items-center justify-center font-bold text-sm">
              {{ user.nombre?.charAt(0).toUpperCase() }}
            </div>
            <div class="flex flex-col leading-tight">
              <span class="text-sm font-semibold">{{ user.nombre }}</span>
              <span class="text-xs text-white/70 capitalize">{{ user.rol }}</span>
            </div>
          </div>

          <button type="button"
            class="font-medium px-4 py-2 rounded-full bg-white/10 border border-white/20 shadow hover:bg-red-500 hover:border-red-500 transition text-center"
            @click="cerrarSesion">
            Cerrar sesión
          </button>
        </template>

        <!-- Sesión móvil: no logueado -->
        <template v-else>
          <NuxtLink to="/login"
            class="font-medium px-4 py-2 rounded-full bg-white/10 border border-white/20 shadow hover:bg-white hover:text-purple-700 transition text-center"
            @click="menuAbierto = false">
            Iniciar sesión
          </NuxtLink>
        </template>
      </div>
    </header>

    <main class="flex-1 pt-24">
      <slot />
    </main>

    <footer class="bg-slate-900 text-slate-300">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 text-center text-sm">
        © 2026 Events
      </div>
    </footer>
  </div>
</template>