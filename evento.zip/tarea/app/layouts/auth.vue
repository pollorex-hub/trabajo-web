<script setup>
</script>

<template>
  <div class="font-sans min-h-screen flex flex-col bg-gradient-to-br from-violet-50 via-indigo-50 to-slate-100 text-slate-900">

    <main class="flex-1">
      <slot />
    </main>

    <footer class="border-t border-violet-100 py-8 px-6">
      <div class="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <span class="font-bold text-lg text-violet-700">My Proyes</span>
        <p class="text-slate-400 text-sm">© 2026 My Proyes. Todos los derechos reservados.</p>
      </div>
    </footer>

  </div>
</template>