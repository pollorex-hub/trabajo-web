<script setup lang="ts">
definePageMeta({
  layout: 'auth'
})

import { z } from 'zod'

const iniciandoSesion = ref(false)
const errorForm = ref('')

const esquemaLogin = z.object({
  email: z
    .string()
    .min(1, 'El correo es requerido')
    .email('Ingresa un correo válido'),
  password: z
    .string()
    .min(1, 'La contraseña es requerida')
    .min(6, 'La contraseña debe tener al menos 6 caracteres')
})

type FormLogin = z.infer<typeof esquemaLogin>

const formLogin = reactive<FormLogin>({
  email: '',
  password: ''
})

const erroresCampos = reactive<Partial<Record<keyof FormLogin, string>>>({
  email: '',
  password: ''
})

function validarCampo(campo: keyof FormLogin) {
  const resultado = esquemaLogin.shape[campo].safeParse(formLogin[campo])
  if (resultado.success) {
    erroresCampos[campo] = ''
  } else {
    erroresCampos[campo] = resultado.error?.issues?.[0]?.message ?? 'Campo inválido'
  }
}

function validarFormulario(): boolean {
  const resultado = esquemaLogin.safeParse(formLogin)

  if (!resultado.success) {
    const errores = resultado.error.flatten().fieldErrors
    erroresCampos.email = errores.email?.[0] ?? ''
    erroresCampos.password = errores.password?.[0] ?? ''
    return false
  }

  erroresCampos.email = ''
  erroresCampos.password = ''
  return true
}

const { fetch: fetchSession } = useUserSession()

async function login() {
  if (!validarFormulario()) return

  iniciandoSesion.value = true
  errorForm.value = ''

  try {
    await $fetch('/api/auth/login', {
      method: 'POST',
      body: {
        email: formLogin.email,
        password: formLogin.password
      }
    })

    await fetchSession()
    await navigateTo('/')
  } catch (err: any) {
    errorForm.value = getApiErrorMessage(err, 'No se pudo iniciar sesión')
  } finally {
    iniciandoSesion.value = false
  }
}
</script>

<template>
  <section class="min-h-screen bg-gradient-to-br from-violet-50 via-indigo-50 to-slate-100 px-4 py-16 sm:px-6 lg:px-8">
    <div class="mx-auto flex max-w-5xl items-center justify-center">
      <UCard class="w-full max-w-md shadow-xl shadow-violet-200/50 ring-1 ring-violet-100">
        <template #header>
          <div class="text-center">
            <!-- Link volver al inicio -->
            <NuxtLink
              to="/"
              class="inline-flex items-center gap-1 text-xs text-violet-400 hover:text-violet-600 transition mb-4"
            >
              <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
              Volver al inicio
            </NuxtLink>

            <!-- Ícono decorativo -->
            <div class="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-500 shadow-lg shadow-violet-300/50">
              <svg class="h-7 w-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </div>

            <p class="text-sm font-semibold uppercase tracking-[0.3em] text-violet-500">
              Acceso
            </p>

            <h1 class="mt-2 text-3xl font-semibold text-violet-700">
              Iniciar sesión
            </h1>

            <p class="mt-2 text-sm text-slate-500">
              Ingresa tu correo y contraseña para entrar al panel.
            </p>
          </div>
        </template>

        <form class="space-y-4" @submit.prevent="login">
          <div>
            <label for="email" class="mb-1 block text-sm font-medium text-slate-700">
              Correo electrónico
            </label>

            <input
              id="email"
              v-model="formLogin.email"
              type="email"
              autocomplete="email"
              placeholder="tu@email.com"
              class="w-full rounded-2xl border bg-white px-4 py-3 text-sm text-slate-900 outline-none transition focus:ring-2"
              :class="erroresCampos.email
                ? 'border-red-400 focus:border-red-500 focus:ring-red-200'
                : 'border-violet-200 focus:border-violet-500 focus:ring-violet-200'"
              @blur="validarCampo('email')"
            />

            <p v-if="erroresCampos.email" class="mt-1 text-xs text-red-500">
              {{ erroresCampos.email }}
            </p>
          </div>

          <div>
            <label for="password" class="mb-1 block text-sm font-medium text-slate-700">
              Contraseña
            </label>

            <input
              id="password"
              v-model="formLogin.password"
              type="password"
              autocomplete="current-password"
              placeholder="••••••••"
              class="w-full rounded-2xl border bg-white px-4 py-3 text-sm text-slate-900 outline-none transition focus:ring-2"
              :class="erroresCampos.password
                ? 'border-red-400 focus:border-red-500 focus:ring-red-200'
                : 'border-violet-200 focus:border-violet-500 focus:ring-violet-200'"
              @blur="validarCampo('password')"
            />

            <p v-if="erroresCampos.password" class="mt-1 text-xs text-red-500">
              {{ erroresCampos.password }}
            </p>
          </div>

          <UAlert
            v-if="errorForm"
            color="error"
            variant="soft"
            :title="errorForm"
          />

          <UButton
            type="submit"
            class="w-full justify-center"
            :loading="iniciandoSesion"
            color="primary"
          >
            Entrar
          </UButton>
        </form>
      </UCard>
    </div>
  </section>
</template>