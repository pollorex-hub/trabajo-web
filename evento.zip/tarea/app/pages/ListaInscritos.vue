<script setup lang="ts">
const route = useRoute()
const eventoId = Number(route.query.id)

const { data: evento, refresh, status } = await useFetch(`/api/Evento/${eventoId}`)

async function eliminarInscrito(id: number) {
    try {
        await $fetch(`/api/Inscrito/${id}`, { method: 'DELETE' })
        await refresh()
    } catch (err) {
        console.error('Error al eliminar inscrito', err)
    }
}
</script>

<template>
    <div class="max-w-3xl mx-auto p-6">
        <UButton
            icon="i-lucide-arrow-left"
            color="primary"
            variant="outline"
            to="/administracion"
            class="mb-4"
        >
            Volver
        </UButton>

        <div class="flex items-center justify-between mb-6">
            <div>
                <h1 class="text-2xl font-bold">{{ evento?.titulo }}</h1>
                <p class="text-sm text-gray-500 dark:text-gray-400">Lista de inscritos</p>
            </div>
            <UBadge
                v-if="evento?.inscrito?.length"
                :label="`${evento.inscrito.length} inscrito${evento.inscrito.length === 1 ? '' : 's'}`"
                color="primary"
                variant="subtle"
                size="lg"
            />
        </div>

        <div v-if="status === 'pending'" class="flex justify-center py-12">
            <UIcon name="i-lucide-loader-2" class="animate-spin size-6 text-gray-400" />
        </div>

        <div
            v-else-if="!evento?.inscrito?.length"
            class="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed p-12 text-center"
        >
            <UIcon name="i-lucide-users" class="size-8 text-gray-400" />
            <p class="text-gray-500 dark:text-gray-400">
                No hay personas inscritas en este evento.
            </p>
        </div>

        <div v-else class="flex flex-col gap-3">
            <div
                v-for="inscrito in evento.inscrito"
                :key="inscrito.id"
                class="flex items-center justify-between rounded-xl border p-4 bg-white dark:bg-gray-900 shadow-sm hover:shadow-md transition-shadow"
            >
                <div class="flex items-center gap-3">
                    <UAvatar
                        :text="`${inscrito.nombre?.[0] ?? ''}${inscrito.apellido?.[0] ?? ''}`"
                        color="primary"
                    />
                    <div>
                        <p class="font-semibold leading-tight">
                            {{ inscrito.nombre }} {{ inscrito.apellido }}
                        </p>
                        <p class="text-sm text-gray-500 dark:text-gray-400">
                            {{ inscrito.email }}
                        </p>
                    </div>
                </div>

                <UButton
                    icon="i-lucide-trash-2"
                    label="Eliminar"
                    color="error"
                    variant="soft"
                    @click="eliminarInscrito(inscrito.id)"
                />
            </div>
        </div>
    </div>
</template>