<script setup lang="ts">
import { ref, reactive } from 'vue'

const guardando = ref(false)
const errorFormulario = ref('')

const FormUsuario = reactive({
  nombre: '',
  apellido: '',
  email: '',
  password: '',
  rol: 'staff'
})

function limpiarFormulario() {
  FormUsuario.nombre = ''
  FormUsuario.apellido = ''
  FormUsuario.email = ''
  FormUsuario.password = ''
  FormUsuario.rol = 'normal'
}

async function guardarUsuario() {
  errorFormulario.value = ''
  guardando.value = true

  try {
    await $fetch('/api/Usuario', {
      method: 'POST',
      body: {
        nombre: FormUsuario.nombre,
        apellido: FormUsuario.apellido,
        email: FormUsuario.email,
        password: FormUsuario.password,
        rol: FormUsuario.rol
      }
    })

    limpiarFormulario()
    // redirigir a administración
    await navigateTo('/administracion')
  } catch (err: any) {
    errorFormulario.value = err?.data?.statusMessage || 'Error al guardar el usuario'
  } finally {
    guardando.value = false
  }
}
</script>

<template>
  <div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-900 p-4">
    <form
      @submit.prevent="guardarUsuario"
      class="w-full max-w-lg p-8 rounded-2xl border border-purple-500/20 bg-white/5 backdrop-blur-xl shadow-2xl shadow-purple-900/30"
    >
      <NuxtLink
        to="/administracion"
        class="inline-flex items-center gap-1.5 text-sm text-purple-200/60 hover:text-purple-200 transition-colors duration-200 mb-6"
      >
        <UIcon name="i-heroicons-arrow-left" class="w-4 h-4" />
        Volver a administración
      </NuxtLink>

      <div class="mb-6 text-center">
        <h2 class="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          Nuevo Usuario
        </h2>
        <p class="text-sm text-purple-200/60 mt-1">Completá los datos para crear una cuenta</p>
      </div>

      <div class="space-y-4">
        <UFormField label="Nombre" name="nombre">
          <UInput
            v-model="FormUsuario.nombre"
            color="primary"
            variant="outline"
            placeholder="Ej: Juan"
            class="w-full"
          />
        </UFormField>

        <UFormField label="Apellido" name="apellido">
          <UInput
            v-model="FormUsuario.apellido"
            color="primary"
            variant="outline"
            placeholder="Ej: Pérez"
            class="w-full"
          />
        </UFormField>

        <UFormField label="Email" name="email">
          <UInput
            v-model="FormUsuario.email"
            color="primary"
            variant="outline"
            placeholder="tu@email.com"
            class="w-full"
          />
        </UFormField>

        <UFormField label="Password" name="password">
          <UInput
            type="password"
            v-model="FormUsuario.password"
            color="primary"
            variant="outline"
            placeholder="Contraseña"
            class="w-full"
          />
        </UFormField>

        <UFormField label="Rol (normal|staff)" name="rol">
          <UInput
            v-model="FormUsuario.rol"
            color="primary"
            variant="outline"
            placeholder="normal"
            class="w-full"
          />
        </UFormField>
      </div>

      <UAlert
        v-if="errorFormulario"
        color="error"
        variant="soft"
        class="mt-5"
        :title="errorFormulario"
      />

      <div class="flex justify-end mt-6">
        <UButton
          type="submit"
          label="Guardar usuario"
          :loading="guardando"
          size="lg"
          class="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white px-6 shadow-lg shadow-purple-900/40 transition-all"
        />
      </div>
    </form>
  </div>
</template>