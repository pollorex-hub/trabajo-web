<script setup lang="ts">
interface EventoInscrito {
  titulo: string
  fecha: string
  lugar: string
}

interface InscripcionPorEmail {
  id: number
  email: string
  nombre: string
  apellido: string
  eventId: number
  eventos: EventoInscrito
}

const email = ref('')
const inscripciones = ref<InscripcionPorEmail[]>([])
const cargando = ref(false)
const mensajeError = ref('')

const emailNormalizado = computed(() => email.value.trim().toLowerCase())

let temporizador: ReturnType<typeof setTimeout> | null = null

async function buscarInscripciones() {
  if (!emailNormalizado.value) {
    inscripciones.value = []
    mensajeError.value = ''
    return
  }

  cargando.value = true
  mensajeError.value = ''

  try {
    inscripciones.value = await $fetch<InscripcionPorEmail[]>(
      `/api/Inscrito/byEmail/${encodeURIComponent(emailNormalizado.value)}`
    )
  } catch (error: any) {
    inscripciones.value = []
    mensajeError.value = getApiErrorMessage(error, 'No se pudieron cargar las inscripciones')
  } finally {
    cargando.value = false
  }
}

watch(email, () => {
  if (temporizador) {
    clearTimeout(temporizador)
  }

  temporizador = setTimeout(() => {
    buscarInscripciones()
  }, 300)
})
</script>
 
<template>
  <div class="mx-auto w-full max-w-3xl px-4 py-6 sm:px-6 lg:px-8">
    <div class="mb-6">
      <h1 class="text-xl font-semibold text-slate-900 sm:text-2xl">Inscritos por correo</h1>
      <p class="mt-1 text-sm text-slate-600 sm:text-base">
        Escribe un correo y verás los eventos guardados en la base de datos para ese usuario.
      </p>
    </div>

    <UInput
      v-model="email"
      type="email"
      placeholder="nombre@correo.com"
      icon="i-lucide-mail"
      size="lg"
      class="mb-3 w-full"
    />

    <UAlert
      v-if="mensajeError"
      class="mb-4"
      color="error"
      variant="soft"
      :title="mensajeError"
    />

    <div v-if="cargando" class="rounded-2xl border border-slate-200 bg-white p-4 text-sm text-slate-500 sm:p-6">
      Buscando inscripciones...
    </div>

    <div v-else-if="emailNormalizado && inscripciones.length === 0" class="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm text-slate-500 sm:p-8">
      No hay inscripciones para este correo.
    </div>
 
    <div v-else class="flex flex-col gap-3 sm:gap-4">
      <InscritoItem
        v-for="inscripcion in inscripciones"
        :key="inscripcion.id"
        :titulo="inscripcion.eventos.titulo"
        :lugar="inscripcion.eventos.lugar"
        :fecha="inscripcion.eventos.fecha"
      />
    </div>
  </div>
</template>