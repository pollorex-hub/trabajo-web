export interface Evento {
  id: number
  titulo: string
  fecha: string
  lugar: string
  imagen: string
  valor: number
  _count?: {
    inscrito: number
  }
}