<script setup lang="ts">
import { formatFechaCorta } from '~/utils/formatters'

interface EventoInscrito {
  titulo: string
  fecha: string
  lugar: string
}

defineProps<{
  titulo: string
  lugar: string
  fecha: string
}>()
</script>

<template>
  <UCard class="shadow-sm w-full">
    <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-4">
      <div class="min-w-0">
        <h3 class="break-words text-sm font-semibold text-indigo-600 sm:text-base">{{ titulo }}</h3>
        <p class="mt-1 text-xs text-slate-500 sm:text-sm">{{ lugar }}</p>
      </div>

      <span class="shrink-0 text-sm font-medium text-slate-600 sm:text-base">
        {{ formatFechaCorta(fecha) }}
      </span>
    </div>
  </UCard>
</template>