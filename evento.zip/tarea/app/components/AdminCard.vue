<script setup lang="ts">
import type { Evento } from '~/types/evento';

const props = defineProps<{
    evento: Evento
}>()

const fechaFormateada = computed(() => formatFechaCorta(props.evento.fecha))
const horaFormateada = computed(() => formatHora(props.evento.fecha))

const emit = defineEmits(['eliminado'])
const eventoBorrar = ref<Evento | null>(null)
const mostrarConfirmBorrar = ref(false)
const borrandoEvento = ref(false)

async function eliminarEvento() {
    borrandoEvento.value = true
    try {
        const idToDelete = eventoBorrar.value?.id ?? props.evento.id
        await $fetch(`/api/Evento/${idToDelete}`, {
            method: 'DELETE'
        })
        const nombreCompleto = eventoBorrar.value?.titulo ?? props.evento.titulo
        cerrarConfirmBorrar()
        emit('eliminado', idToDelete)
        useToast().add({
            duration: 2000,
            icon: 'i-lucide-trash-2',
            title: 'Borrado de Evento',
            description: `Se borró el evento ${nombreCompleto}`
        })
    } catch (err) {
        console.error('Error al eliminar', err)
    } finally {
        borrandoEvento.value = false
    }
}

function confirmarBorrarEvento(evento: Evento) {
    eventoBorrar.value = evento
    mostrarConfirmBorrar.value = true
}

function cerrarConfirmBorrar() {
    mostrarConfirmBorrar.value = false
    eventoBorrar.value = null
}


</script>

<template>


    <div
        class="overflow-hidden rounded-3xl border border-white/20 bg-white/10 backdrop-blur-xl shadow-2xl shadow-slate-950/30">
        <img class="h-56 w-full object-cover" alt="mi foto" :src="evento.imagen" />
        <div class="p-6">
            <p class="text-sm uppercase tracking-[0.25em] text-blue-300">{{ evento.titulo }}</p>
            <div class="mt-4 space-y-3 text-white">
                <p><span class="font-semibold text-white">Lugar:</span> {{ evento.lugar }}</p>
                <p><span class="font-semibold text-white">fecha:</span> {{ fechaFormateada }}</p>
                <p><span class="font-semibold text-white">Hora:</span> {{ horaFormateada }}</p>
                <p><span class="font-semibold text-white">Valor:</span> ${{ evento.valor }}</p>
                <p class="m-0 text-white">
                    <span class="font-semibold text-white">Inscritos:</span>
                    {{ evento._count?.inscrito ?? 0 }}
                </p>
            </div>
            <div class="mt-6 flex justify-end gap-2">
                <UButton label="Inscritos" color="neutral"
                    :to="{ path: '/ListaInscritos', query: { id: evento.id } }" />

                <UButton label="Eliminar" color="error" @click="confirmarBorrarEvento(props.evento)" />

            </div>


        </div>
    </div>

    <!-- Confirmación de borrado -->
    <Teleport to="body">
        <Transition name="fade">
            <div v-if="mostrarConfirmBorrar"
                class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4"
                @click.self="cerrarConfirmBorrar">
                <div class="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-slate-900">Confirmar borrado</h3>
                        <button type="button" class="rounded-full p-1 text-slate-500 hover:bg-slate-100"
                            @click="cerrarConfirmBorrar">✕</button>
                    </div>
                    <p class="mt-2 text-sm text-slate-600">¿Deseas eliminar el evento: <strong>{{ eventoBorrar?.titulo }}</strong>?</p>

                    <div class="mt-6 flex justify-end gap-3">
                        <button type="button"
                            class="rounded-2xl border border-slate-300 bg-white px-4 py-2 text-sm text-slate-700 hover:bg-slate-100"
                            @click="cerrarConfirmBorrar">
                            Cancelar
                        </button>
                        <button type="button"
                            class="rounded-2xl bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
                            :disabled="borrandoEvento"
                            @click="eliminarEvento">
                            {{ borrandoEvento ? 'Borrando...' : 'Eliminar' }}
                        </button>
                    </div>
                </div>
            </div>
        </Transition>
    </Teleport>

</template>