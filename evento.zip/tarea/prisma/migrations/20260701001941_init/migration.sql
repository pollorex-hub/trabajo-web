-- DropForeignKey
ALTER TABLE `inscritos` DROP FOREIGN KEY `Inscritos_eventId_fkey`;

-- AddForeignKey
ALTER TABLE `Inscritos` ADD CONSTRAINT `Inscritos_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Evento`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
