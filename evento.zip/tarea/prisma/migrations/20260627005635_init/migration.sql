-- CreateTable
CREATE TABLE `Usuario` (
    `email` VARCHAR(100) NOT NULL,
    `password` VARCHAR(60) NOT NULL,
    `apellido` VARCHAR(100) NOT NULL,
    `nombre` VARCHAR(100) NOT NULL,
    `rol` VARCHAR(20) NOT NULL,

    PRIMARY KEY (`email`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Evento` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `titulo` VARCHAR(60) NOT NULL,
    `fecha` DATETIME(3) NOT NULL,
    `lugar` VARCHAR(100) NOT NULL,
    `imagen` VARCHAR(191) NOT NULL,
    `valor` INTEGER NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Inscritos` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `email` VARCHAR(100) NOT NULL,
    `apellido` VARCHAR(100) NOT NULL,
    `nombre` VARCHAR(100) NOT NULL,
    `eventId` INTEGER NOT NULL,

    INDEX `Inscritos_eventId_idx`(`eventId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Inscritos` ADD CONSTRAINT `Inscritos_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Evento`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
